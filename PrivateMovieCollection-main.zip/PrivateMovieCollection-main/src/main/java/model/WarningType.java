package model;

public enum WarningType {
    NONE,
    OLD_NO_RATING,
    OLD_LOW_RATING,
}
